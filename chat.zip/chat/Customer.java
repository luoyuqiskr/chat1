public class Customer extends Object implements java.io.Serializable
{
	
	private static final long serialVersionUID = -9215977405584592618L;
	/**
	 * �û���
	 */
	public String custName;
	/**
	 * ����
	 */
	public String custPassword;
	/**
	 * �û�ͷ��
	 */
	public String custHead;
}