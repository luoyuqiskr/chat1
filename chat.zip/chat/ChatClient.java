public class ChatClient
{

	public ChatClient()
	{
	}

	public static void main(String args[])
	{
		new Login();
	}
}
