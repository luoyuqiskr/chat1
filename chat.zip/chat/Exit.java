

import java.io.Serializable;


public class Exit implements Serializable
{

	private static final long serialVersionUID = -5267537916643834426L;
	/**
	 * �˳����û���
	 */
	public String exitname;	
}